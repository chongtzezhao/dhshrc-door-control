#!/bin/sh
# launcher sh

cd /
cd home/pi/Desktop/door
sudo python3 door-bot.py
cd /
