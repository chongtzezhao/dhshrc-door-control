from time import sleep
import telepot
from telepot.loop import MessageLoop
from pprint import pprint
from datetime import datetime as dt
import pigpio
from threading import Thread
print("bot starting...")
# CONSTANTS AND AUTHORISATION DATA

token = '1065181249:AAFZu_58l-xJtjzoSKTK7arLeo2k0NynbxA'
bot = telepot.Bot(token)
bot.sendMessage(956428669, 'starting..')

CHAT_IDS = {956428669:"TZ", 68180890:"SP", 910250337:"TS", 372601813:"KK", 471781296:"AC"}
COMMANDS = ["Open"]
KEYBOARD = {"keyboard":[ ["Open"] ]}
PIN = 2
PW_MIN = 550
PW_MAX = 2250

disengaged = 1500
engaged = PW_MAX

def newDatetime():
    return str(dt.now())[:-7]

def log(chat_id, username, name, text):
    arr = [newDatetime(), chat_id, username, name, text]
    arr = [str(i) for i in arr]
    try:
        with open("messages.txt", "a") as file:
            file.write(','.join(arr))
            file.write("\n")
    except:
        with open("messages.txt", "w") as file:
            file.write(','.join(arr))
            file.write("\n")
    

def handle(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)
    username = msg['chat']['username']
    try:
        name = msg['chat']['first_name'] + ' '+ msg['chat']['last_name']
    except:
        name = msg['chat']['first_name']
    
    if content_type == 'text':
        
        log(chat_id, username, name, msg['text'])
        
        if chat_id not in CHAT_IDS:
            bot.sendMessage(chat_id, "You have not registered your telegram ID. Please message @shrcrequestbot to get added.", reply_markup=KEYBOARD)
            return

        cmd = msg['text'].capitalize()

        if dt.today().weekday()>4 or dt.now().hour<7 or dt.now().hour+(dt.now().minute/60)>=6.75+12:
            bot.sendMessage(chat_id, "Room is out of bounds. Door not unlocked", reply_markup=KEYBOARD)
            return

        if cmd not in COMMANDS:
            bot.sendMessage(chat_id, 'Invalid command. Send "open" to unlock door', reply_markup=KEYBOARD)
            return
        
        io = pigpio.pi()
        io.set_servo_pulsewidth(PIN, engaged)
        sleep(0.4)
        io.set_servo_pulsewidth(PIN, disengaged)
        sleep(1)
        io.set_PWM_dutycycle(PIN, 0)
        bot.sendMessage(chat_id, 'Door successfully unlocked', reply_markup=KEYBOARD)
        
MessageLoop(bot, handle).run_forever()


