#!/bin/sh
# launcher sh

cd /
cd home/pi/Desktop/door/
sudo pigpiod
sudo python3 door-bluetooth.py
cd /
