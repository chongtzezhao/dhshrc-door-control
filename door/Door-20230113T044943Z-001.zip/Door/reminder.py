import requests
from datetime import datetime as dt
from time import sleep
import random

token = "1065181249:AAFZu_58l-xJtjzoSKTK7arLeo2k0NynbxA"
url = "https://api.telegram.org/bot" + token
#link = "https://api.telegram.org/bot1065181249:AAFZu_58l-xJtjzoSKTK7arLeo2k0NynbxA/sendMessage?chat_id=956428669&text=hi"
CHAT_IDS = {956428669:"TZ", 68180890:"SP", 910250337:"TS", 372601813:"KK", 471781296:"AC"}

while True:
    while dt.today().weekday()>4:
        sleep(1)
    while dt.now().hour!=7:
        sleep(1)
    with open("motivation.txt") as file:
        lines = file.readlines()
        lines = [line.strip() for line in lines]
        index = random.randint(1, len(lines)-1)
        text = lines[index]
    for id in CHAT_IDS:
        requests.get(url + "/sendMessage?chat_id=" + str(id) + "&text=" + text)
    while dt.now().hour==7:
        sleep(1)
