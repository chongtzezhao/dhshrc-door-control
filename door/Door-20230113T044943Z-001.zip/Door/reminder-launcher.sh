#!/bin/sh
# launcher sh

cd /
cd home/pi/Desktop/door
sudo python3 reminder.py
cd /
