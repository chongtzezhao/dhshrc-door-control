open terminal "CTRL + ALT + T"
Enter "sudo crontab -e"
scroll down to the bottom and add the following lines:

@reboot sleep 18;sh /home/pi/Desktop/door/doorblue-launcher.sh &
@reboot sleep 20;sh /home/pi/Desktop/door/doorbot-launcher.sh &

Move the folder "door" to desktop
Change the bot token to the correct bot.
Done!