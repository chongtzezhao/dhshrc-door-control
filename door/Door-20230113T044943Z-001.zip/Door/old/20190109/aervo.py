import pigpio
from time import sleep

io = pigpio.pi()

engaged = 2000
disengaged = 1200
PIN = 2

for i in range(5):
    io.set_servo_pulsewidth(PIN, engaged)
    sleep(0.5)
    io.set_servo_pulsewidth(PIN, disengaged)
    sleep(1)
