import telepot
from telepot.loop import MessageLoop
from pprint import pprint
import datetime
from time import sleep
import pigpio

token = '1065181249:AAFZu_58l-xJtjzoSKTK7arLeo2k0NynbxA'
bot = telepot.Bot(token)
io = pigpio.pi()


CHAT_IDS = [956428669]
COMMANDS = ["open", "Open"]

PIN = 2
PW_MIN = 550
PW_MAX = 2250

disengaged = 1400
engaged = PW_MAX

io.set_servo_pulsewidth(PIN, disengaged)

def handle(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)
    if content_type == 'text':
        
        if chat_id not in CHAT_IDS:
            bot.sendMessage(chat_id, "You have not registered your telegram ID. Please message @shrcrequestbot to get added.")
            return

        if datetime.datetime.today().weekday()>4 or datetime.datetime.now().hour<7 or datetime.datetime.now().hour>5+12:
            bot.sendMessage(chat_id, "Room is out of bounds. Door not unlocked")
            return

        if msg['text'] not in COMMANDS:
            bot.sendMessage(chat_id, 'Invalid command. Send "open" to unlock door')
            return
        
        io.set_servo_pulsewidth(PIN, engaged)
        sleep(0.4)
        io.set_servo_pulsewidth(PIN, disengaged)
        bot.sendMessage(chat_id, 'Door successfully unlocked')
        
    with open("msessages.txt", "w+") as file:
        file.write(str(chat_id) + ' ' + msg['text'] + "\n")

MessageLoop(bot, handle).run_as_thread()
