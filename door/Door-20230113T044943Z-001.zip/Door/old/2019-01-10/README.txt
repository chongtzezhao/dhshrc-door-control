sudo apt-get update
sudo python3 -m pip install pybluez

sudo crontab -e
@reboot [COMMAND]
